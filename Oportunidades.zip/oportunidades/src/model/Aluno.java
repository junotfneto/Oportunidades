package model;

import java.util.ArrayList;
import controller.*;

public class Aluno extends Usuario {
	private int matricula;
	private int semestreAtual;
	private int previsaoConclusao; 
	private String curso;
	private String qualificacao;
	private String experiencia;
        
        public Aluno(long id, String nome, String email, String telefone, String senha){
            super(id, nome, email, telefone, senha);
        }
	public Aluno(long id, String nome, String email, String telefone, String senha, int mat, int semA, int prev, String curso, String qual, String exp){
            super(id, nome, email, telefone, senha);
            this.matricula = mat;
            this.semestreAtual = semA;
            this.previsaoConclusao = prev;
            this.curso = curso;
            this.qualificacao = qual;
            this.experiencia = exp;
        }

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public int getSemestreAtual() {
		return semestreAtual;
	}

	public void setSemestreAtual(int semestreAtual) {
		this.semestreAtual = semestreAtual;
	}

	public int getPrevisaoConclusao() {
		return previsaoConclusao;
	}

	public void setPrevisaoConclusao(int previsaoConclusao) {
		this.previsaoConclusao = previsaoConclusao;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getQualificacao() {
		return qualificacao;
	}

	public void setQualificacao(String qualificacao) {
		this.qualificacao = qualificacao;
	}

	public String getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
        
        public String toString(){
            return getId()+" - "+getNome();
        }

        public boolean estaInteressado(Oportunidade oportunidade){
            ArrayList<Vaga> al = new VagaController().vagasAluno(this);
            int i;
            for(i = 0; i < al.size(); i++){
                if(al.get(i).getOportunidade().equals(oportunidade))
                    return true;
            }
            return false;          
        }
	
}
