/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Jun
 */
public class Vaga {
    private Oportunidade oportunidade;
    private Aluno aluno;
    private Docente orientador;
    
    public Vaga(Oportunidade oportunidade, Aluno aluno, Docente orientador){
        this.oportunidade = oportunidade;
        this.aluno = aluno;
        this.orientador = orientador;
    }

    public Oportunidade getOportunidade() {
        return oportunidade;
    }

    public void setOportunidade(Oportunidade oportunidade) {
        this.oportunidade = oportunidade;
    }

    public Aluno getAluno() {
        return aluno;
    }

    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }

    public Docente getOrientador() {
        return orientador;
    }
    
    public void setOrientador(Docente docente){
        orientador = docente;
    }
    
    public boolean equals(Vaga v){
        boolean ret = aluno.getId() == v.getAluno().getId();
        ret = ret && (oportunidade.equals(v.getOportunidade()));
        ret = ret && (orientador.getId() == v.getOrientador().getId());
        return ret;
    }
    
    public String toString(){
        return oportunidade.toString();
    }
}
