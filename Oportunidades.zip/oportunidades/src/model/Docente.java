package model;
public class Docente extends Usuario{
	private String area;
        public static final Docente vazio = new Docente(-1, "nenhum", "", "", "");
        
        public Docente(long id, String nome, String email, String telefone, String senha){
            super(id, nome, email, telefone, senha);
        }
		
	
	public Docente(long id, String nome, String email, String telefone, String senha, String area) {
		super(id, nome, email, telefone, senha);
		this.area = area;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	
}
