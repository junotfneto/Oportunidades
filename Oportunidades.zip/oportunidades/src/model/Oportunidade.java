package model;
public class Oportunidade {

	private String titulo, area, descricao, requisitos;
	private int cargaHoraria;	
	private double remuneracao;
        private long idEmpresa;
//Construtor	
	public Oportunidade(String titulo, String area, String descricao, int cargaHoraria, double remuneracao, String requisitos, long idEmpresa) {
		this.titulo = titulo;
		this.area = area;
		this.descricao = descricao;
		this.cargaHoraria = cargaHoraria;
		this.remuneracao = remuneracao;
                this.requisitos = requisitos;
                this.idEmpresa = idEmpresa;
	}
//FimConstrutor
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getCargaHoraria() {
		return cargaHoraria;
	}

	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

	public double getRemuneracao() {
		return remuneracao;
	}

	public void setRemuneracao(double remuneracao) {
		this.remuneracao = remuneracao;
	}

        public String getRequisitos(){
            return requisitos;
        }
	
        public void setRequisitos(String requisitos){
            this.requisitos = requisitos;
        }
	
        public long getIdEmpresa(){
            return idEmpresa;
        }
        
        public void setIdEmpresa(long id){
            idEmpresa = id;
        }
	
        public String toString(){
            return titulo;
        }
        
        public boolean equals(Oportunidade o){
            boolean ret = titulo.equals(o.getTitulo());
            ret = ret &&(idEmpresa == o.getIdEmpresa());
            return ret;
        }
}
