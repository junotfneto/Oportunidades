package model;
public class Empresa extends Usuario{
	
	private String endereco, area, descricao;
        
        public Empresa(long id, String nome, String email, String telefone, String senha){
            super(id, nome, email, telefone, senha);
        }
        
        public Empresa(long id, String nome, String email, String telefone, String senha, String endereco, String area, String descricao){
            super(id, nome, email, telefone, senha);
            this.endereco = endereco;
            this.area = area;
            this.descricao = descricao;
        }
	
	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
        
        public void setArea(String area){
            this.area = area;
        }
        
	public String getArea(){
            return area;
        }
        
        public void setDescricao(String descricao){
            this.descricao = descricao;
        }
        
        public String getDescricao(){
            return descricao;
        }
        
        public String toString(){
            return nome;
        }
}
