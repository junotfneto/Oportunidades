package controller;

import java.util.ArrayList;
import model.*;

public class DocenteController {
    
    public boolean cadastraDocente(Docente docente) {
                if(findDocenteById(docente.getId()) != null)
                    return false;
                if(new AlunoController().findAlunoById(docente.getId()) != null)
                    return false;
		Arquivo arquivo = Arquivo.getInstance();
		return arquivo.salvarArquivoDocente(docente);
    }
    
    public ArrayList<Docente> getAll(){
            return Arquivo.getInstance().getAllDocentes();
    }
    
    public Docente findDocenteById(long id){
            ArrayList<Docente> l = getAll();
            int i;
            for(i = 0; i < l.size(); i++){
                Docente al = l.get(i);
                if(al.getId() == id)
                    return al;
            }
            return null;
        }
	
    void supervisionarAluno(){
        
    }
}
