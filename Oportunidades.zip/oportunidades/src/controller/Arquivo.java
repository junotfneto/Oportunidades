package controller;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

import model.Aluno;
import model.Docente;
import model.Empresa;
import model.Oportunidade;
import model.Vaga;
import utils.*;

public class Arquivo extends EscolherArquivo{
    
    private static Arquivo instance = null;
    private Diretorios bd;
    
    
    public static Arquivo getInstance(){
        if(instance == null)
            instance = new Arquivo();
        return instance;
    }
    
    private Arquivo(){
        try {
            bd = new Diretorios("BancoDeDados");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
	
	
	/*
	 * 		Aluno
	 */
	
	public boolean salvarArquivoAluno(Aluno aluno){
		Arquivos arq;
		try{
                    arq = new Arquivos(bd, "alunos.txt");
                    String CadastroCompleto = Serializador.serializaAluno(aluno);
			
                    arq.iniciaEscrita();
                    arq.escreve(CadastroCompleto);
                    arq.novaLinha();
                    arq.acabaEscrita();
                    return true;
			//JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
			
		}catch(Exception e){ 
			JOptionPane.showMessageDialog(null, "Exception Caught : " +e.getMessage());
                        return false;
		}
	}
        
        public ArrayList<Aluno> getAllAlunos(){
            Arquivos arq;
            ArrayList<Aluno> al = new ArrayList<Aluno>();
            try {
                arq = new Arquivos(bd, "alunos.txt");
                arq.iniciaLeitura();
                String in;
                in = arq.leArquivo();
                while(in != null){
                    Aluno a = Serializador.getAluno(in);
                    if(a != null)
                        al.add(a);
                    in = arq.leArquivo();
                }
                
                arq.acabaLeitura();
            } catch (IOException ex) {
                Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
            }
            return al;
        }

/*
 * 		Docente
 */


    public boolean salvarArquivoDocente(Docente docente){
	
	try{
            Arquivos arq = new Arquivos(bd, "docentes.txt");
            String CadastroCompleto = null;
            CadastroCompleto = Serializador.serializaDocente(docente);
            arq.iniciaEscrita();
            arq.escreve(CadastroCompleto);
            arq.novaLinha();
            arq.acabaEscrita();
            //JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
            return true;

	}catch(Exception e){ 
            JOptionPane.showMessageDialog(null, "Exception Caught : " +e.getMessage());
            return false;
	} 
    }

    public ArrayList<Docente> getAllDocentes(){
            Arquivos arq;
            ArrayList<Docente> al = new ArrayList<Docente>();
            try {
                arq = new Arquivos(bd, "docentes.txt");
                arq.iniciaLeitura();
                String in;
                in = arq.leArquivo();
                while(in != null){
                    Docente a = Serializador.getDocente(in);
                    if(a != null)
                        al.add(a);
                    in = arq.leArquivo();
                }
                
                arq.acabaLeitura();
            } catch (IOException ex) {
                Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
            }
            return al;
        }

/*
 * 		Empresa
 */


    public boolean salvarArquivoEmpresa(Empresa empresa){
	
	try{
            Arquivos arq = new Arquivos(bd, "empresas.txt");
            String CadastroCompleto = Serializador.serializaEmpresa(empresa);
            arq.iniciaEscrita();
            arq.escreve(CadastroCompleto);
            arq.novaLinha();
            arq.acabaEscrita();
            return true;

	}catch(Exception e){ 
            JOptionPane.showMessageDialog(null, "Exception Caught : " +e.getMessage());
            return false;
	}
        
    }

    public ArrayList<Empresa> getAllEmpresas(){
            Arquivos arq;
            ArrayList<Empresa> al = new ArrayList<Empresa>();
            try {
                arq = new Arquivos(bd, "empresas.txt");
                arq.iniciaLeitura();
                String in;
                in = arq.leArquivo();
                while(in != null){
                    Empresa a = Serializador.getEmpresa(in);
                    if(a != null)
                        al.add(a);
                    in = arq.leArquivo();
                }
                
                arq.acabaLeitura();
            } catch (IOException ex) {
                Logger.getLogger(Arquivo.class.getName()).log(Level.SEVERE, null, ex);
            }
            return al;
        }
/*
 * 	Oportunidades
 */


    public boolean salvarArquivoOportunidade(Oportunidade oportunidade){
	
	try{
		String CadastroCompleto = Serializador.serializaOportunidade(oportunidade);
		Arquivos arq = new Arquivos(bd, "oportunidades.txt");
                arq.iniciaEscrita();
                arq.escreve(CadastroCompleto);
                arq.novaLinha();
                arq.acabaEscrita();
                return true;
	}catch(Exception e){ 
            JOptionPane.showMessageDialog(null, "Exception Caught : " +e.getMessage());
            return false;
	}
	
    }
    
    public ArrayList<Oportunidade> getAllOportunidades(){
        ArrayList<Oportunidade> al = new ArrayList<Oportunidade>();
        Arquivos arq;
        String in;
        try{
            arq = new Arquivos(bd, "oportunidades.txt");
            arq.iniciaLeitura();
            in = arq.leArquivo();
            while(in != null){
                Oportunidade op = Serializador.getOportunidade(in);
                if(op != null)
                    al.add(op);
                in = arq.leArquivo();
            }
            arq.acabaLeitura();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return al;
    }
    
    public void apagaOportunidade(Oportunidade o){
        ArrayList<Oportunidade> al = getAllOportunidades();
        Arquivos arq;
        try{
            arq = new Arquivos(bd, "oportunidades.txt");
            arq.delete();
            int i;
            for(i = 0; i < al.size(); i++){
                if((o.getTitulo().equals(al.get(i).getTitulo()))&&(o.getIdEmpresa() == al.get(i).getIdEmpresa()))
                    continue;
                salvarArquivoOportunidade(al.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /*
    *  Vagas
    */
    
    public boolean salvarArquivoVaga(Vaga vaga){
	
	try{
		String CadastroCompleto = Serializador.serializaVaga(vaga);
		Arquivos arq = new Arquivos(bd, "vagas.txt");
                arq.iniciaEscrita();
                arq.escreve(CadastroCompleto);
                arq.novaLinha();
                arq.acabaEscrita();
                return true;
	}catch(Exception e){ 
            JOptionPane.showMessageDialog(null, "Exception Caught : " +e.getMessage());
            return false;
	}
	
    }
    
    public ArrayList<Vaga> getAllVagas(){
        ArrayList<Vaga> al = new ArrayList<Vaga>();
        Arquivos arq;
        String in;
        try{
            arq = new Arquivos(bd, "vagas.txt");
            arq.iniciaLeitura();
            in = arq.leArquivo();
            while(in != null){
                Vaga op = Serializador.getVaga(in);
                if(op != null)
                    al.add(op);
                in = arq.leArquivo();
            }
            arq.acabaLeitura();
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return al;
    }
    
    public void apagaVaga(Vaga o){
        ArrayList<Vaga> al = getAllVagas();
        Arquivos arq;
        try{
            arq = new Arquivos(bd, "vagas.txt");
            arq.delete();
            int i;
            for(i = 0; i < al.size(); i++){
                if(o.equals(al.get(i)))
                    continue;
                salvarArquivoVaga(al.get(i));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
	
}