package controller;

import java.util.ArrayList;
import model.Oportunidade;

public class OportunidadeController {
	
    public boolean cadastraOportunidade(Oportunidade oportunidade){
        Arquivo arquivo = Arquivo.getInstance();
        return arquivo.salvarArquivoOportunidade(oportunidade);
    }
    
    public ArrayList<Oportunidade> getAll(){
        return Arquivo.getInstance().getAllOportunidades();
    }
    
    public Oportunidade findOportunidade(String titulo, long id){
        ArrayList<Oportunidade> al = getAll();
        int i;
        for(i = 0; i < al.size(); i++){
            Oportunidade op = al.get(i);
            if(op.getTitulo().equals(titulo)&&(op.getIdEmpresa() == id))
                return op;
        }
        return null;
    }
    
    public ArrayList<Oportunidade> getAll(long idEmpresa){
            ArrayList<Oportunidade> al1, al2;
            al1 = getAll();
            al2 = new ArrayList<Oportunidade>();
            int i;
            for(i = 0; i < al1.size(); i++){
                //System.out.println(al1.get(i).getIdEmpresa()+" == "+idEmpresa);
                if(al1.get(i).getIdEmpresa() == idEmpresa)
                    al2.add(al1.get(i));
            }
            return al2;
        }
		
}


