/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.*;

/**
 *
 * @author Jun
 */
public class UsuarioController {
    
    public static Usuario login(long id, String senha){
        Aluno al = new AlunoController().findAlunoById(id);
        if(al != null){
            //System.out.println(al);
            //System.out.println(al.getSenha()+"=="+senha);
            if(al.getSenha().equals(senha))
                return al;
        
        }   
        Docente dc = new DocenteController().findDocenteById(id);
        if(dc != null){
            if(dc.getSenha().equals(senha))
                return dc;
        }
        Empresa em = new EmpresaController().findEmpresaById(id);
        if(em != null){
            if(em.getSenha().equals(senha))
                return em;
        }
        return null;
    }
    
        
}
