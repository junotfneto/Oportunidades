package controller;

import java.util.ArrayList;
import model.*;

public class EmpresaController {
    
        public boolean cadastraEmpresa(Empresa empresa){
            if(findEmpresaById(empresa.getId()) != null)
                    return false;
            if(new AlunoController().findAlunoById(empresa.getId()) != null)
                return false;
            if(new DocenteController().findDocenteById(empresa.getId()) != null)
                return false;
            Arquivo arquivo = Arquivo.getInstance();
            return arquivo.salvarArquivoEmpresa(empresa);
        }
        
        public Empresa findEmpresaById(long id){
            ArrayList<Empresa> l = getAll();
            int i;
            for(i = 0; i < l.size(); i++){
                Empresa al = l.get(i);
                if(al.getId() == id)
                    return al;
            }
            return null;
        }
        
        public ArrayList<Empresa> getAll(){
            return Arquivo.getInstance().getAllEmpresas();
        }

        public ArrayList<Oportunidade> getOportunidades(Empresa empresa){
            return new OportunidadeController().getAll(empresa.getId());
        }
	
}
