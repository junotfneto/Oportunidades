package controller;

import java.util.ArrayList;
import model.Aluno;

public class AlunoController {
	
	//private Aluno aluno;
	
	public boolean cadastraAluno(Aluno aluno) {
                if(findAlunoById(aluno.getId()) != null)
                    return false;
                if(new DocenteController().findDocenteById(aluno.getId()) != null)
                    return false;
		Arquivo arquivo = Arquivo.getInstance();
		return arquivo.salvarArquivoAluno(aluno);
	}
	
	public boolean informarInteresse(Aluno interesse){
            Arquivo arquivo = Arquivo.getInstance();
	
		
			arquivo.salvarArquivoAluno(interesse);
		
		return false;
	}
        public ArrayList<Aluno> getAll(){
            return Arquivo.getInstance().getAllAlunos();
        }
        
        public Aluno findAlunoById(long id){
            ArrayList<Aluno> l = getAll();
            int i;
            for(i = 0; i < l.size(); i++){
                Aluno al = l.get(i);
                if(al.getId() == id)
                    return al;
            }
            return null;
        }
	
}
