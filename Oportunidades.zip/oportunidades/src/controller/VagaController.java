/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import model.*;

/**
 *
 * @author Jun
 */
public class VagaController {
    
    public boolean cadastraVaga(Vaga vaga){
        Arquivo arquivo = Arquivo.getInstance();
        return arquivo.salvarArquivoVaga(vaga);
    }
    public ArrayList<Vaga> getAll(){
        return Arquivo.getInstance().getAllVagas();
    }
    
    public ArrayList<Vaga> vagasAluno(Aluno aluno){
        ArrayList<Vaga> al = getAll();
        ArrayList<Vaga> ret = new ArrayList<>();
        int i;
        for(i = 0; i < al.size(); i++){
            if(al.get(i).getAluno().getId() == aluno.getId())
                ret.add(al.get(i));
        }
        return ret;
    }
    public ArrayList<Vaga> vagasOportunidade(Oportunidade oportunidade){
        ArrayList<Vaga> al = getAll();
        ArrayList<Vaga> ret = new ArrayList<>();
        int i;
        for(i = 0; i < al.size(); i++){
            if(al.get(i).getOportunidade().equals(oportunidade))
                ret.add(al.get(i));
        }
        return ret;
    }
}
