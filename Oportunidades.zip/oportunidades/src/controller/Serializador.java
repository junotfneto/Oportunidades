/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.*;

/**
 *
 * @author Jun
 */
public class Serializador {
    
    public static Aluno getAluno(String serial){
        String  sId, sNome, sEmail, sSenha, sTelefone, sMatricula, sSemestreAtual, sConclusao, sCurso, sQualificacao, sExperiencia;
        try{
            sId = serial.substring(serial.indexOf("<id>")+4, serial.indexOf("<nome>"));
            sNome = serial.substring(serial.indexOf("<nome>")+6, serial.indexOf("<email>"));
            sEmail = serial.substring(serial.indexOf("<email>")+7, serial.indexOf("<senha>"));
            sSenha = serial.substring(serial.indexOf("<senha>")+7, serial.indexOf("<telefone>"));
            sTelefone = serial.substring(serial.indexOf("<telefone>")+10, serial.indexOf("<matricula>"));
            sMatricula = serial.substring(serial.indexOf("<matricula>")+11, serial.indexOf("<semestreAtual>"));
            sSemestreAtual = serial.substring(serial.indexOf("<semestreAtual>")+15, serial.indexOf("<previsaoConclusao>"));
            sConclusao = serial.substring(serial.indexOf("<previsaoConclusao>")+19, serial.indexOf("<Curso>"));
            sCurso = serial.substring(serial.indexOf("<Curso>")+7, serial.indexOf("<qualificacao>"));
            sQualificacao = serial.substring(serial.indexOf("<qualificacao>")+14, serial.indexOf("<experiencia>"));
            sExperiencia = serial.substring(serial.indexOf("<experiencia>")+13);

            Aluno al;
            al = new Aluno(Long.parseLong(sId), sNome, sEmail, sTelefone, sSenha, Integer.parseInt(sMatricula),
                    Integer.parseInt(sSemestreAtual), Integer.parseInt(sConclusao), sCurso, sQualificacao, sExperiencia);
            return al;
        }catch(Exception e){
            return null;
        }
    }
    public static String serializaAluno(Aluno aluno){
        String CadastroCompleto = null;
                    CadastroCompleto = "<id>"+aluno.getId()
					+"<nome>"+aluno.getNome()
					+"<email>"+aluno.getEmail()
					+"<senha>"+aluno.getSenha()
					+"<telefone>"+aluno.getTelefone()
					+"<matricula>"+aluno.getMatricula()
					+"<semestreAtual>"+aluno.getSemestreAtual()
					+"<previsaoConclusao>"+aluno.getPrevisaoConclusao()
					+"<Curso>"+aluno.getCurso()
					+"<qualificacao>"+aluno.getQualificacao()
					+"<experiencia>"+aluno.getExperiencia();
        return CadastroCompleto;
    }
    
    public static String serializaDocente(Docente docente){
        String CadastroCompleto = null;
	CadastroCompleto = "<id>"+docente.getId()
			+"<nome>"+docente.getNome().toString()
			+"<email>"+docente.getEmail().toString()
			+"<senha>"+docente.getSenha()
			+"<telefone>"+docente.getTelefone().toString()
			+"<area>"+docente.getArea();
        return CadastroCompleto;
    }
    
    public static Docente getDocente(String serial){
        String  sId, sNome, sEmail, sSenha, sTelefone, sArea;
        try{
            sId = serial.substring(serial.indexOf("<id>")+4, serial.indexOf("<nome>"));
            sNome = serial.substring(serial.indexOf("<nome>")+6, serial.indexOf("<email>"));
            sEmail = serial.substring(serial.indexOf("<email>")+7, serial.indexOf("<senha>"));
            sSenha = serial.substring(serial.indexOf("<senha>")+7, serial.indexOf("<telefone>"));
            sTelefone = serial.substring(serial.indexOf("<telefone>")+10, serial.indexOf("<area>"));
            sArea = serial.substring(serial.indexOf("<area>")+6);
            Docente al;
            al = new Docente(Long.parseLong(sId), sNome, sEmail, sTelefone, sSenha, sArea);
            return al;
        }catch(Exception e){
            return null;
        }
    }
    
    public static String serializaEmpresa(Empresa empresa){
        String CadastroCompleto = null;
	CadastroCompleto = "<id>"+empresa.getId()
		+"<nome>"+empresa.getNome()
		+"<email>"+empresa.getEmail()
		+"<senha>"+empresa.getSenha()
		+"<telefone>"+empresa.getTelefone()
                +"<endereco>"+empresa.getEndereco()
                +"<area>"+empresa.getArea()
                +"<desc>"+empresa.getDescricao();
        return CadastroCompleto;
    }
    
    public static Empresa getEmpresa(String serial){
        String  sId, sNome, sEmail, sSenha, sTelefone, sEndereco, sArea, sDesc;
        try{
            sId = serial.substring(serial.indexOf("<id>")+4, serial.indexOf("<nome>"));
            sNome = serial.substring(serial.indexOf("<nome>")+6, serial.indexOf("<email>"));
            sEmail = serial.substring(serial.indexOf("<email>")+7, serial.indexOf("<senha>"));
            sSenha = serial.substring(serial.indexOf("<senha>")+7, serial.indexOf("<telefone>"));
            sTelefone = serial.substring(serial.indexOf("<telefone>")+10, serial.indexOf("<endereco>"));
            sEndereco = serial.substring(serial.indexOf("<endereco>")+10, serial.indexOf("<area>"));
            sArea = serial.substring(serial.indexOf("<area>")+6, serial.indexOf("<desc>"));
            sDesc = serial.substring(serial.indexOf("<desc>")+6);
            Empresa al;
            al = new Empresa(Long.parseLong(sId), sNome, sEmail, sTelefone, sSenha, sEndereco, sArea, sDesc);
            return al;
        }catch(Exception e){
            return null;
        }
    }
    
    public static String serializaOportunidade(Oportunidade oportunidade){
        String CadastroCompleto = null;
	CadastroCompleto = "<titulo>"+oportunidade.getTitulo()
                +"<area>"+oportunidade.getArea()
		+"<desc>"+oportunidade.getDescricao()
		+"<carga>"+oportunidade.getCargaHoraria()
		+"<remuneracao>"+oportunidade.getRemuneracao()
                +"<requisitos>"+oportunidade.getRequisitos()
                +"<id>"+oportunidade.getIdEmpresa();
        
        return CadastroCompleto;
    }
    
    public static Oportunidade getOportunidade(String serial){
        try{
            String  sTitulo, sDesc, sCarga, sRem, sReq, sArea, sId;
            sTitulo = serial.substring(serial.indexOf("<titulo>")+8, serial.indexOf("<area>"));
            sArea = serial.substring(serial.indexOf("<area>")+6, serial.indexOf("<desc>"));
            sDesc = serial.substring(serial.indexOf("<desc>")+6, serial.indexOf("<carga>"));
            sCarga = serial.substring(serial.indexOf("<carga>")+7, serial.indexOf("<remuneracao>"));
            sRem = serial.substring(serial.indexOf("<remuneracao>")+13, serial.indexOf("<requisitos>"));
            sReq = serial.substring(serial.indexOf("<requisitos>")+12, serial.indexOf("<id>"));
            sId = serial.substring(serial.indexOf("<id>")+4);
            Oportunidade op = new Oportunidade(sTitulo, sArea, sDesc, Integer.parseInt(sCarga), Double.parseDouble(sRem), sReq, Long.parseLong(sId));
            return op;
        }catch(Exception e){
            return null;
        }
    }
    
    public static String serializaVaga(Vaga vaga){
        String CadastroCompleto = null;
	CadastroCompleto = "<idAluno>"+vaga.getAluno().getId()
                +"<idEmpresa>"+vaga.getOportunidade().getIdEmpresa()
		+"<titulo>"+vaga.getOportunidade().getTitulo()
		+"<idProf>"+vaga.getOrientador().getId();
        
        return CadastroCompleto;
    }
    
    public static Vaga getVaga(String serial){
        String sAluno, sEmpresa, sTitulo, sProf;
        try{
            sAluno = serial.substring(serial.indexOf("<idAluno>")+9, serial.indexOf("<idEmpresa>"));
            sEmpresa = serial.substring(serial.indexOf("<idEmpresa>")+11, serial.indexOf("<titulo>"));
            sTitulo = serial.substring(serial.indexOf("<titulo>")+8, serial.indexOf("<idProf>"));
            sProf = serial.substring(serial.indexOf("<idProf>")+8);
            Aluno al = new AlunoController().findAlunoById(Long.parseLong(sAluno));
            Docente pr = new DocenteController().findDocenteById(Long.parseLong(sProf));
            Oportunidade op = new OportunidadeController().findOportunidade(sTitulo, Long.parseLong(sEmpresa));
            Vaga v = new Vaga(op, al, pr);
            return v;
        }catch(Exception e){
            return null;
        }
    }
}
