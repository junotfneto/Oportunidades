package main;

import view.*;
import model.*;
import controller.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ViewPrincipal.getInstance().setVisible(true);
    }

}
