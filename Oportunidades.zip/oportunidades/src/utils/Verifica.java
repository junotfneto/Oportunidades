/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author Jun
 */
public class Verifica {
    
    public static boolean isLong(String in){
        try{
            long i = Long.parseLong(in);
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    public static boolean isInt(String in){
        try{
            int i = Integer.parseInt(in);
            return true;
        }catch(Exception e){
            return false;
        }
    }
    
    public static boolean isDouble(String in){
        try{
            double i = Double.parseDouble(in);
            return true;
        }catch(Exception e){
            return false;
        }
    }
}
